<?php return array (
  'add-comment' => 'App\\Http\\Livewire\\AddComment',
  'add-post-feed' => 'App\\Http\\Livewire\\AddPostFeed',
  'all-message' => 'App\\Http\\Livewire\\AllMessage',
  'fetch-posts' => 'App\\Http\\Livewire\\FetchPosts',
  'inicio' => 'App\\Http\\Livewire\\Inicio',
  'posted' => 'App\\Http\\Livewire\\Posted',
  'send-message' => 'App\\Http\\Livewire\\SendMessage',
);