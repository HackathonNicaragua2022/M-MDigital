<div>

    

  <form wire:submit.prevent="store" class="grid gap-3">
      <?php if(session()->has('success')): ?>
          <span class="text-green-500">
              <?php echo e(session()->get('success')); ?>

          </span>
      <?php endif; ?>


      <!-- component -->


      <style>
          html,
          body {
              font-family: Poppins, Helvetica, sans-serif;
          }
      </style>



      <!-- User Profile Tab Card -->
      <div class="flex flex-row rounded-lg border border-gray-200/80 bg-white p-6">
          <!-- Avaar Container -->
          <div class="relative">
              <!-- User Avatar -->
              <img class="w-20 h-20 rounded-md object-cover" src="<?php echo e(Auth::user()->profile_photo_url); ?>"
                  alt="<?php echo e(Auth::user()->name); ?>" />

              <!-- Online Status Dot -->
              
          </div>

          <!-- Meta Body -->
          <div class="flex flex-col px-6">
              <!-- Username Container -->
              <div class="flex h-8 flex-row">
                  <!-- Username -->
                  <a href="#" target="_blank">
                      <h3 class="text-lg font-semibold"><?php echo e(Auth::user()->name); ?></h3>
                  </a>

                  <!-- User Verified -->
                  <svg class="my-auto ml-2 h-5 fill-blue-400" xmlns="http://www.w3.org/2000/svg"
                      xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" width="24" height="24"
                      viewBox="0 0 24 24">
                      <path
                          d="M23,12L20.56,9.22L20.9,5.54L17.29,4.72L15.4,1.54L12,3L8.6,1.54L6.71,4.72L3.1,5.53L3.44,9.21L1,12L3.44,14.78L3.1,18.47L6.71,19.29L8.6,22.47L12,21L15.4,22.46L17.29,19.28L20.9,18.46L20.56,14.78L23,12M10,17L6,13L7.41,11.59L10,14.17L16.59,7.58L18,9L10,17Z" />
                  </svg>
              </div>

              

              <!-- Meta Badges -->

              <div class="my-2 flex flex-row space-x-2">
                  <!-- Badge Role -->
                  <div class="flex flex-row">
                      <svg class="mr-2 h-4 w-4 fill-gray-500/80" xmlns="http://www.w3.org/2000/svg"
                          xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" width="24" height="24"
                          viewBox="0 0 24 24">
                          <path
                              d="M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M7.07,18.28C7.5,17.38 10.12,16.5 12,16.5C13.88,16.5 16.5,17.38 16.93,18.28C15.57,19.36 13.86,20 12,20C10.14,20 8.43,19.36 7.07,18.28M18.36,16.83C16.93,15.09 13.46,14.5 12,14.5C10.54,14.5 7.07,15.09 5.64,16.83C4.62,15.5 4,13.82 4,12C4,7.59 7.59,4 12,4C16.41,4 20,7.59 20,12C20,13.82 19.38,15.5 18.36,16.83M12,6C10.06,6 8.5,7.56 8.5,9.5C8.5,11.44 10.06,13 12,13C13.94,13 15.5,11.44 15.5,9.5C15.5,7.56 13.94,6 12,6M12,11A1.5,1.5 0 0,1 10.5,9.5A1.5,1.5 0 0,1 12,8A1.5,1.5 0 0,1 13.5,9.5A1.5,1.5 0 0,1 12,11Z" />
                      </svg>

                      <div class="text-xs text-gray-400/80 hover:text-gray-400"><?php echo e(Auth::user()->name); ?></div>
                  </div>

                  <!-- Badge Location -->
                  

                  <!-- Badge Email-->

                  <div class="my-2 flex flex-row space-x-2">
                      <!-- Badge Role -->
                      <div class="flex flex-row">
                  <div class="flex h-8 flex-row">
                      <div class="flex flex-row">
                          <svg class="ml-4 mr-2 h-4 w-4 fill-gray-500/80" xmlns="http://www.w3.org/2000/svg"
                              xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" width="24" height="24"
                              viewBox="0 0 24 24">
                              <path
                                  d="M12,15C12.81,15 13.5,14.7 14.11,14.11C14.7,13.5 15,12.81 15,12C15,11.19 14.7,10.5 14.11,9.89C13.5,9.3 12.81,9 12,9C11.19,9 10.5,9.3 9.89,9.89C9.3,10.5 9,11.19 9,12C9,12.81 9.3,13.5 9.89,14.11C10.5,14.7 11.19,15 12,15M12,2C14.75,2 17.1,3 19.05,4.95C21,6.9 22,9.25 22,12V13.45C22,14.45 21.65,15.3 21,16C20.3,16.67 19.5,17 18.5,17C17.3,17 16.31,16.5 15.56,15.5C14.56,16.5 13.38,17 12,17C10.63,17 9.45,16.5 8.46,15.54C7.5,14.55 7,13.38 7,12C7,10.63 7.5,9.45 8.46,8.46C9.45,7.5 10.63,7 12,7C13.38,7 14.55,7.5 15.54,8.46C16.5,9.45 17,10.63 17,12V13.45C17,13.86 17.16,14.22 17.46,14.53C17.76,14.84 18.11,15 18.5,15C18.92,15 19.27,14.84 19.57,14.53C19.87,14.22 20,13.86 20,13.45V12C20,9.81 19.23,7.93 17.65,6.35C16.07,4.77 14.19,4 12,4C9.81,4 7.93,4.77 6.35,6.35C4.77,7.93 4,9.81 4,12C4,14.19 4.77,16.07 6.35,17.65C7.93,19.23 9.81,20 12,20H17V22H12C9.25,22 6.9,21 4.95,19.05C3,17.1 2,14.75 2,12C2,9.25 3,6.9 4.95,4.95C6.9,3 9.25,2 12,2Z" />
                          </svg>

                          <div class="text-xs text-gray-400/80 hover:text-gray-400"><?php echo e(Auth::user()->email); ?></div>
                      </div>
                  </div>
                      </div>
                  </div>

                  <!-- Mini Cards -->
                  <div class="mt-2 flex flex-row items-center space-x-5">
                      <!-- Comments -->
                      
                  </div>
              </div>



              <!-- Right Actions Container -->
              <div class="w-100 flex flex-grow flex-col items-end justify-start">
                  <div class="flex flex-row space-x-3">
                      <!-- Follow Button -->
                      
                  </div>
              </div>
          </div>
      </div>




      <div wire:loading class='m-12 space-y-6'>
          <div class="bg-red-100 border-t border-b border-red-500 text-red-700 px-4 py-3" role="alert">
              <p class="text-center font-bold">¡Porfavor espere!</p>
              <p class="text-center text-sm">Su imagen se esta subiendo</p>
          </div>
      </div>



      <?php if($coverImage): ?>
          <img class=" mt-3 mb-4 w-60 h-60 rounded-md object-cover" src="<?php echo e($coverImage->temporaryUrl()); ?>">
      <?php endif; ?>






      <div class="grid>
          <label for=">Imagen:</label>
          <input type="file" wire:model="coverImage"
              class=" block w-full text-sm text-gray-900 border border-gray-300 rounded-lg cursor-pointer bg-gray-50 dark:text-gray-400 focus:outline-none dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400"
              id="">

          <?php $__errorArgs = ['coverImage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="text-red-500">
                  <?php echo e($message); ?>

              </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      

      <div class="grid>
  <label for="></label>
          <textarea wire:model="body" id=""
              class=" mt-3 block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
              placeholder="Escriba su mensaje..." cols="40" rows="2"></textarea>
          <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="text-red-500">
                  <?php echo e($message); ?>

              </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="py-3">

          <button type="submit" wire:submit.prevent="store"
              class="disabled:opacity-25 px-6 py-2 bg-indigo-500 outline-none rounded text-white shadow-indigo-200 shadow-lg font-medium active:shadow-none active:scale-95 hover:bg-indigo-600 focus:bg-indigo-600 focus:ring-2 focus:ring-indigo-600 focus:ring-offset-2 disabled:bg-gray-400/80 disabled:shadow-none disabled:cursor-not-allowed transition-colors duration-200"><span
                  wire:loading>Cargando</span> Post </button>


      </div>
  </form>

</div>
<?php /**PATH C:\Users\Limber Rodriguez\Desktop\olpe.1\resources\views/livewire/add-post-feed.blade.php ENDPATH**/ ?>