<img src="img\Recurso 17-8.png" alt="">
<?php /**PATH C:\Users\Limber Rodriguez\Desktop\olpe.1\resources\views/vendor/jetstream/components/application-mark.blade.php ENDPATH**/ ?>