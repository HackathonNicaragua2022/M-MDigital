<a href="/">
    <img src="img\Recurso 15-8.png" alt="">
</a><?php /**PATH C:\Users\Limber Rodriguez\Desktop\olpe\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>